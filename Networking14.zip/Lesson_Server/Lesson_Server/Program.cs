﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_Server
{
    class Program
    {
        //https://www.youtube.com/c/HavingTeam
        static void Main(string[] args)
        {
            Server server = new Server(6565, 100);
            server.AcceptAsync();
            while (true)
                Console.ReadLine();
        }
    }
}
