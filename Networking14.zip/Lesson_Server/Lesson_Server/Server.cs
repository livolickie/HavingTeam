﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Collections.Concurrent;

namespace Lesson_Server
{
    class Server
    {
        //https://www.youtube.com/c/HavingTeam
        Socket socket;
        ConcurrentDictionary<int, Player> players;
        int[] idMap;

        public Server(short port, int backlog)
        {
            socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            socket.Bind(new IPEndPoint(IPAddress.Any, port));
            socket.Listen(backlog);
            players = new ConcurrentDictionary<int, Player>();
            idMap = new int[backlog];
            for (int i = 0; i < idMap.Length; i++)
                idMap[i] = -1;
        }

        public async void AcceptAsync()
        {
            if (socket != null)
            {
                Socket newSocket = await AcceptAsyncTask();
                if (newSocket != null)
                {
                    Console.WriteLine("New connection from {0}", (newSocket.RemoteEndPoint as IPEndPoint).Address.ToString());
                    int id = getId();
                    Buffer buffer = new Buffer();
                    buffer.WriteU8(0);
                    buffer.WriteU16((short)id);
                    newSocket.Send(buffer.GetData());
                    buffer.Clear();
                    Player p = new Player(newSocket, id);
                    players.TryAdd(id, p);
                    p.StartTimer(ref players, ref idMap);
                    ReceiveTCPAsync(p);
                }
                AcceptAsync();
            }
        }

        public Task<Socket> AcceptAsyncTask()
        {
            return Task.Run(() => {
                Socket newSocket = socket.Accept();
                return newSocket;
            });
        }

        public async void ReceiveTCPAsync(Player player)
        {
            if (player.socket != null)
            {
                int size = await ReceiveTCPAsyncTask(player);
                if (size != 0)
                {
                    Buffer buffer = new Buffer();
                    Buffer buff = new Buffer(player.data);
                    int messageId = buff.ReadU8();
                    switch (messageId)
                    {
                        case 0:
                            Console.WriteLine(buff.ReadString());
                            break;

                        case 1:
                            player.timeout = true;
                            break;

                        case 2:
                            buffer.SeekStart();
                            buffer.WriteU8(2);
                            player.socket.Send(buffer.GetData(), 0, buffer.Tell(), 0);
                            break;
                    }
                    buff.Clear();
                    buffer.Clear();
                    ReceiveTCPAsync(player);
                }
                else
                {
                    player.timer.Stop();
                    player.timer.Dispose();
                    players.TryRemove(player.id, out player);
                    player.socket.Close();
                    idMap[player.id] = -1;
                    Console.WriteLine("{0} disconnected!", player.id);
                }
            }
        }

        public Task<int> ReceiveTCPAsyncTask(Player p)
        {
            return Task.Run(() => {
                int size = p.socket.Receive(p.data);
                return size;
            });
        }

        public int getId()
        {
            for(int i = 0; i < idMap.Length; i++)
                if (idMap[i] == -1)
                {
                    idMap[i] = 1;
                    return i;
                }
            return -1;
        }
    }
}
