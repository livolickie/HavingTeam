<?php
include "db.php";
mysqli_query($connection,"SELECT * FROM users ORDER BY score DESC");
$result = mysqli_query($connection,"SELECT MAX(id) FROM users");
$row = mysqli_fetch_row($result);
$max_id = $row[0];
$a[$max_id][4];
for($i = 1; $i<=$max_id; $i++)
	{
		$result = mysqli_query($connection,"SELECT * FROM users WHERE id = '$i'");
		$temp_array = mysqli_fetch_row($result);
		$a[$i][0] = $temp_array[0];
		$a[$i][1] = $temp_array[1];
		$a[$i][2] = $temp_array[2];
 	}
$json = json_encode($a);
echo $json;
?>