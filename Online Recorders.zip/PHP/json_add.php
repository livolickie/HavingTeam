<?php
include "db.php";
$USERNAME = $_POST["username"];
$SCORE = $_POST["score"];
$result = mysqli_query($connection,"SELECT * FROM users WHERE username = '$USERNAME'");
if ($result == false)
{
	exit(mysqli_error($connection));
}
$array = mysqli_fetch_row($result);
if (empty($array))
{
	mysqli_query($connection,"INSERT INTO users (username,score) VALUE ('$USERNAME','$SCORE')");
}
else
{
	mysqli_query($connection,"UPDATE users SET score = '$SCORE' WHERE username = '$USERNAME'");
}
?>