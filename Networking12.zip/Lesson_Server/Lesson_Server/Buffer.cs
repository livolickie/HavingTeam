﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Lesson_Server
{
    class Buffer
    {
        //https://www.youtube.com/c/HavingTeam
        MemoryStream stream;
        BinaryWriter bw;

        public Buffer()
        {
            stream = new MemoryStream();
            bw = new BinaryWriter(stream);
        }

        public void WriteString(string val)
        {
            for (int i = 0; i < val.Length; i++)
                bw.Write(val[i]);
            bw.Write('\0');
        }

        public byte[] GetData()
        {
            return stream.ToArray();
        }

        public void Clear()
        {
            bw.Close();
            bw.Dispose();
            stream.Close();
            stream.Dispose();
        }
    }
}
