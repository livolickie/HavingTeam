﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;

namespace Lesson_Server
{
    class Server
    {
        //https://www.youtube.com/c/HavingTeam
        Socket socket;

        public Server(short port, int backlog)
        {
            socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            socket.Bind(new IPEndPoint(IPAddress.Any, port));
            socket.Listen(backlog);
        }

        public void Accept()
        {
            while (socket != null)
            {
                Console.WriteLine("Waiting connections...");
                Socket newSocket = socket.Accept();
                if (newSocket != null)
                {
                    Console.WriteLine("New connection from {0}", (newSocket.RemoteEndPoint as IPEndPoint).Address.ToString());
                    Buffer buffer = new Buffer();
                    buffer.WriteString("Hello, player! " + (newSocket.RemoteEndPoint as IPEndPoint).Address.ToString());
                    newSocket.Send(buffer.GetData());
                    buffer.Clear();
                    newSocket.Close();
                }
            }
        }
    }
}
