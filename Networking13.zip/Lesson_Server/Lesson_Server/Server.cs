﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Collections.Concurrent;

namespace Lesson_Server
{
    class Server
    {
        //https://www.youtube.com/c/HavingTeam
        Socket socket;
        ConcurrentDictionary<int, Player> players;
        int[] idMap;

        public Server(short port, int backlog)
        {
            socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            socket.Bind(new IPEndPoint(IPAddress.Any, port));
            socket.Listen(backlog);
            players = new ConcurrentDictionary<int, Player>();
            idMap = new int[backlog];
            for (int i = 0; i < idMap.Length; i++)
                idMap[i] = -1;
            Thread t = new Thread(ReceiveTCP);
            t.Start();
        }

        public void Accept()
        {
            while (socket != null)
            {
                Console.WriteLine("Waiting connections...");
                Socket newSocket = socket.Accept();
                if (newSocket != null)
                {
                    Console.WriteLine("New connection from {0}", (newSocket.RemoteEndPoint as IPEndPoint).Address.ToString());
                    int id = getId();
                    Buffer buffer = new Buffer();
                    buffer.WriteU8(0);
                    buffer.WriteU16((short)id);
                    newSocket.Send(buffer.GetData());
                    buffer.Clear();
                    newSocket.Blocking = false;
                    Player p = new Player(newSocket, id);
                    players.TryAdd(id, p);
                    p.StartTimer(ref players, ref idMap);
                }
            }
        }

        public void ReceiveTCP()
        {
            byte[] data = new byte[256];
            Buffer buffer = new Buffer();
            while(socket != null)
            {
                foreach(var player in players.Values)
                { 
                    if (player != null)
                    {
                        if (player.socket.Available > 0)
                        {
                            int size = player.socket.Receive(data);
                            Buffer buff = new Buffer(data);
                            int messageId = buff.ReadU8();
                            switch(messageId)
                            {
                                case 0:
                                    Console.WriteLine(buff.ReadString());
                                    break;

                                case 1:
                                    player.timeout = true;
                                    break;

                                case 2:
                                    buffer.SeekStart();
                                    buffer.WriteU8(2);
                                    player.socket.Send(buffer.GetData(), 0, buffer.Tell(), 0);
                                    break;
                            }
                            buff.Clear();
                        }
                    }
                }
            }
            buffer.Clear();
        }

        public int getId()
        {
            for(int i = 0; i < idMap.Length; i++)
                if (idMap[i] == -1)
                {
                    idMap[i] = 1;
                    return i;
                }
            return -1;
        }
    }
}
