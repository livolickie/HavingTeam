﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Lesson_Server
{
    class Buffer
    {
        //https://www.youtube.com/c/HavingTeam
        MemoryStream stream;
        BinaryWriter bw;
        BinaryReader br;

        public Buffer()
        {
            stream = new MemoryStream();
            bw = new BinaryWriter(stream);
            br = new BinaryReader(stream);
        }

        public Buffer(byte[] data)
        {
            stream = new MemoryStream(data);
            bw = new BinaryWriter(stream);
            br = new BinaryReader(stream);
        }

        public void WriteU8(byte val)
        {
            bw.Write(val);
        }

        public void WriteU16(short val)
        {
            bw.Write(val);
        }

        public void WriteString(string val)
        {
            for (int i = 0; i < val.Length; i++)
                bw.Write(val[i]);
            bw.Write('\0');
        }

        public byte ReadU8()
        {
            return br.ReadByte();
        }

        public short ReadU16()
        {
            return br.ReadInt16();
        }

        public string ReadString()
        {
            string str = "";
            char ch;
            while ((int)(ch = br.ReadChar()) != 0)
                str += ch;
            return str;
        }

        public byte[] GetData()
        {
            return stream.ToArray();
        }

        public int Tell()
        {
            return (int)stream.Position;
        }

        public void SeekStart()
        {
            stream.Seek(0, SeekOrigin.Begin);
        }

        public void Clear()
        {
            bw.Close();
            bw.Dispose();
            stream.Close();
            stream.Dispose();
        }
    }
}
