﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Timers;
using System.Collections.Concurrent;

namespace Lesson_Server
{
    //https://www.youtube.com/c/HavingTeam
    class Player
    {
        public Socket socket { get; private set; }
        int id;
        Timer timer;
        ConcurrentDictionary<int, Player> players;
        int[] idMap;
        public bool timeout = true;

        public Player(Socket socket, int id)
        {
            this.socket = socket;
            this.id = id;
        }

        public void StartTimer(ref ConcurrentDictionary<int, Player> players, ref int[] idMap)
        {
            this.players = players;
            this.idMap = idMap;
            timer = new System.Timers.Timer(1500);
            timer.AutoReset = true;
            timer.Elapsed += Timer_Elapsed;
            timer.Start();
        }

        private void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            if (timeout)
            {
                socket.Send(new byte[1] { 1 });
                timeout = false;
            }
            else
            {
                timer.Close();
                timer.Dispose();
                Player p = this;
                Console.WriteLine("{0} disconnected!", id);
                players.TryRemove(id, out p);
                idMap[id] = -1;
            }
        }
    }
}
